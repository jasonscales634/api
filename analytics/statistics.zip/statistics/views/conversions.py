from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from analytics.statistics.serializers.conversions import ConversionCreateSerializer


class ConversionCreateView(APIView):
    serializer_class = ConversionCreateSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():
            conversion = serializer.save()
            return Response({
                "status": 1,
                "message": "Conversion created successfully",
                "data": {
                    "id": str(conversion.id)
                }
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                "status": 0,
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
