from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Count, Sum

from analytics.statistics.models.clicks import Click
from tracker.models import Conversion


class AffiliateStatsAPIView(APIView):
    def get(self, request):
        # Conversion থেকে affiliate_id অনুযায়ী group করে stats তৈরি করা
        stats = (
            Conversion.objects
            .values('click__affiliate_id')  # Conversion → Click → affiliate_id
            .annotate(
                total_conversions=Count('id'),
                total_revenue=Sum('revenue'),
                total_clicks=Count('click')  # Count of related clicks
            )
            .order_by('-total_revenue')
        )

        return Response({
            "status": 1,
            "results": stats
        })
