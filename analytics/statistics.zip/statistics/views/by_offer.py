from rest_framework.views import APIView
from rest_framework.response import Response
from django.db.models import Sum
from analytics.statistics.models.statistics import DailyStat

from offer.models import Offer  # ✅ Offer model import
from offer.serializers import OfferBreakdownSerializer  # ✅ Corrected Serializer import


class OfferBreakdownAPIView(APIView):
    def get(self, request):
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')

        stats = DailyStat.objects.all()
        if start_date and end_date:
            stats = stats.filter(date__range=[start_date, end_date])

        # Stats per offer_id with aggregates
        data = stats.values('offer_id').annotate(
            raw_clicks=Sum('raw_clicks'),
            unique_clicks=Sum('unique_clicks'),
            conversions=Sum('conversions'),
            revenue=Sum('revenue'),
            earning=Sum('earning'),
        ).order_by('-revenue')

        # Offer details mapping
        offer_ids = [d['offer_id'] for d in data if d['offer_id']]
        offer_map = {offer.id: offer for offer in Offer.objects.filter(id__in=offer_ids)}

        # Inject offer_title and replace offer_id with offer.offer_id
        for d in data:
            offer = offer_map.get(d['offer_id'])
            d['offer_title'] = offer.title if offer else ""
            d['offer_id'] = str(offer.offer_id) if offer and offer.offer_id else str(d['offer_id'])

        # Serialize and respond
        serializer = OfferBreakdownSerializer(data, many=True)
        return Response({
            "status": 1,
            "results": serializer.data
        })