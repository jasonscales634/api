from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from analytics.statistics.serializers.conversion import ConversionCreateSerializer
from tracker.models import Conversion

class ConversionCreateView(APIView):
    serializer_class = ConversionCreateSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data)

        if serializer.is_valid():
            conversion = serializer.save()
            return Response({
                "status": 1,
                "message": "Conversion created successfully",
                "data": {
                    "id": str(conversion.id),
                    "transaction_id": conversion.transaction_id,
                    "click": str(conversion.click.id) if conversion.click else None,
                    "goal": str(conversion.goal.id) if conversion.goal else None,
                    "revenue": str(conversion.revenue),
                    "payout": str(conversion.payout),
                    "status": conversion.status,
                    "created_at": conversion.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                }
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                "status": 0,
                "message": "Invalid data",
                "errors": serializer.errors
            }, status=status.HTTP_400_BAD_REQUEST)
